import { Authenticated, Unauthenticated, useQuery, useMutation } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "./components/ui/toaster";
import { useState, useRef } from "react";
import { useToast } from "./hooks/use-toast";

export default function App() {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="sticky top-0 z-10 bg-white/80 backdrop-blur-sm p-4 flex justify-between items-center border-b">
        <h2 className="text-xl font-semibold accent-text">Arabic Text to Speech</h2>
        <SignOutButton />
      </header>
      <main className="flex-1 flex items-center justify-center p-8">
        <div className="w-full max-w-md mx-auto">
          <Content />
        </div>
      </main>
      <Toaster />
    </div>
  );
}

function Content() {
  const loggedInUser = useQuery(api.auth.loggedInUser);
  const savedTexts = useQuery(api.textToSpeech.listTexts);
  const saveText = useMutation(api.textToSpeech.saveText);
  const [text, setText] = useState("");
  const { toast } = useToast();
  const synth = useRef(window.speechSynthesis);

  const handleSpeak = () => {
    if (!text) return;

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = "ar";
    synth.current.speak(utterance);
    
    saveText({ text })
      .then(() => {
        toast({
          title: "Text saved",
          description: "Your text has been saved and can be replayed later.",
        });
      })
      .catch((error) => {
        toast({
          title: "Error",
          description: "Failed to save text: " + error.message,
          variant: "destructive",
        });
      });
  };

  if (loggedInUser === undefined) {
    return (
      <div className="flex justify-center items-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-500"></div>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-8">
      <div className="text-center">
        <h1 className="text-5xl font-bold accent-text mb-4">Arabic Text to Speech</h1>
        <Authenticated>
          <p className="text-xl text-slate-600">Welcome, {loggedInUser?.email ?? "friend"}!</p>
        </Authenticated>
        <Unauthenticated>
          <p className="text-xl text-slate-600">Sign in to get started</p>
        </Unauthenticated>
      </div>

      <Unauthenticated>
        <SignInForm />
      </Unauthenticated>

      <Authenticated>
        <div className="flex flex-col gap-4">
          <textarea
            dir="rtl"
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="اكتب النص العربي هنا..."
            className="w-full p-4 border rounded-lg min-h-[100px] text-right"
          />
          <button
            onClick={handleSpeak}
            className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition"
          >
            Convert to Speech
          </button>

          {savedTexts && savedTexts.length > 0 && (
            <div className="mt-8">
              <h3 className="text-lg font-semibold mb-4">Saved Texts</h3>
              <div className="space-y-2">
                {savedTexts.map((entry) => (
                  <div
                    key={entry._id}
                    className="p-4 border rounded-lg cursor-pointer hover:bg-gray-50"
                    onClick={() => {
                      const utterance = new SpeechSynthesisUtterance(entry.text);
                      utterance.lang = "ar";
                      synth.current.speak(utterance);
                    }}
                  >
                    <p dir="rtl" className="text-right">{entry.text}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </Authenticated>
    </div>
  );
}
